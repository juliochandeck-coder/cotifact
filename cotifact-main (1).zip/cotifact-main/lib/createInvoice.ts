import { SupabaseClient } from "@supabase/supabase-js";
import { Quote, CompanySettings } from "@/types";

export type CreateInvoiceResult =
  | { ok: true; id: string; number: string }
  | { ok: false; message: string; duplicate?: boolean };

/**
 * Crea una factura a partir de una cotizacion aprobada.
 * Se usa desde el detalle de la cotizacion y desde el boton rapido del listado,
 * para que la logica de numeracion y copia de datos viva en un solo sitio.
 */
export async function createInvoiceFromQuote(
  supabase: SupabaseClient,
  quote: Quote,
  company: CompanySettings | null,
  /** Número de factura escrito por el usuario (la numeración es manual). */
  invoiceNumber: string
): Promise<CreateInvoiceResult> {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return { ok: false, message: "Tu sesión expiró. Vuelve a iniciar sesión." };
  }

  invoiceNumber = (invoiceNumber ?? "").trim();
  if (!invoiceNumber) {
    return { ok: false, message: "Escribe el número de factura." };
  }

  const termDays = company?.payment_terms_days ?? 15;
  const due = new Date();
  due.setDate(due.getDate() + termDays);

  // El check de "requiere DGI" se precarga desde lo guardado en el cliente
  // del directorio, si existe uno enlazado — se puede cambiar despues sin
  // que afecte lo que quedo guardado en el directorio.
  let requiresDgi = false;
  if (quote.client_id) {
    const { data: client } = await supabase
      .from("clients")
      .select("requires_dgi_default")
      .eq("id", quote.client_id)
      .maybeSingle();
    requiresDgi = client?.requires_dgi_default ?? false;
  }

  const { data, error: insertError } = await supabase
    .from("invoices")
    .insert({
      quote_id: quote.id,
      user_id: user.id,
      invoice_number: invoiceNumber,
      client_name: quote.client_name,
      client_company: quote.client_company,
      client_email: quote.client_email,
      client_phone: quote.client_phone,
      items: quote.items,
      subtotal: quote.subtotal,
      tax_rate: quote.tax_rate,
      tax_amount: quote.tax_amount,
      total: quote.total,
      notes: quote.notes,
      project_name: quote.project_name,
      project_description: quote.project_description,
      due_date: due.toISOString().slice(0, 10),
      status: "pendiente",
      requires_dgi: requiresDgi,
      // Los retainers se facturan cada mes desde la misma cotizacion:
      // esta marca los saca de la regla de "una sola factura por cotizacion".
      is_retainer_invoice: quote.is_retainer,
    })
    .select("id, invoice_number")
    .single();

  if (insertError || !data) {
    // 23505 = indice unico: numero repetido, o ya existe factura para esta cotizacion.
    if (insertError?.code === "23505") {
      if (/invoice_number|user_number/i.test(insertError.message ?? "")) {
        return {
          ok: false,
          message: `Ya tienes otra factura con el número ${invoiceNumber}. Usa uno distinto.`,
        };
      }
      return {
        ok: false,
        duplicate: true,
        message: "Esta cotización ya tiene una factura. Recarga la página para verla.",
      };
    }
    return {
      ok: false,
      message: "No se pudo generar la factura. " + (insertError?.message ?? ""),
    };
  }

  return { ok: true, id: data.id, number: data.invoice_number };
}
